#!/usr/bin/python

import struct
import socket

rawSocket = socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
rawSocket.bind(("enp2s0", socket.htons(0x0800)))

source_mac = "00:0a:f7:2b:69:49"        # sender mac address
source_ip  = "10.32.143.78"           # sender ip address
dest_ip  = "10.32.143.1"             # target ip address
dest_mac = "\xff\xff\xff\xff\xff\xff"   # target mac address

def arp_req(source_mac,source_ip,dest_ip):
	# Ethernet Header
	protocol = 0x0806                       # 0x0806 for ARP
	eth_hdr = struct.pack("!6s6sH", dest_mac, source_mac, protocol)

	# ARP header
	htype = 1                               # Hardware_type ethernet
	ptype = 0x0800                          # Protocol type IP
	hlen = 6                                # Hardware address Len
	plen = 4                                # Protocol addr. len
	operation = 1                           # 1=request/2=reply
	src_ip = socket.inet_aton(source_ip)
	dst_ip = socket.inet_aton(dest_ip)
	arp_hdr = struct.pack("!HHBBH6s4s6s4s", htype, ptype, hlen, plen, operation, source_mac, src_ip, dest_mac, dst_ip)

	packet = eth_hdr + arp_hdr
	rawSocket.send(packet)

def arp_rep(source_mac,source_ip,dest_ip,dest_mac):
	dest_mac = "\xff\xff\xff\xff\xff\xff"   # target mac address
	# Ethernet Header
	protocol = 0x0806                       # 0x0806 for ARP
	eth_hdr = struct.pack("!6s6sH", dest_mac, source_mac, protocol)

	# ARP header
	htype = 1                               # Hardware_type ethernet
	ptype = 0x0800                          # Protocol type IP
	hlen = 6                                # Hardware address Len
	plen = 4                                # Protocol addr. len
	operation = 2                           # 1=request/2=reply
	src_ip = socket.inet_aton(source_ip)
	dst_ip = socket.inet_aton(dest_ip)
	arp_hdr = struct.pack("!HHBBH6s4s6s4s", htype, ptype, hlen, plen, operation, source_mac, src_ip, dest_mac, dst_ip)

	packet = eth_hdr + arp_hdr
	rawSocket.send(packet)

if __name__ == "__main__":
	import sys
	print sys.argv
	args = sys.argv[1:]

	if len(args) == 0:
		print 'Usage : sudo python2 arp.py <reply|request> <source_mac> <source_ip> <dest_ip> [dest_mac]'
		print 'dest_mac -> only necessary for reply'
		exit(0)

	if args[0].lower() == "request":
		if len(args) < 4:
			print 'Not enough args'
			print 'Usage : sudo python2 arp.py request <source_mac> <source_ip> <dest_ip>'
			exit(0)
		source_mac = args[1]
		source_ip = args[2]
		dest_ip = args[3]
		print 'Sending request in broadcast from {}@{} asking for {}'.format(args[2],args[1],args[3])
		arp_req(source_mac,source_ip,dest_ip)
	elif args[0].lower() == "reply":
		if len(args) < 5:
			print 'Not enough args'
			print 'Usage : sudo python2 arp.py reply <source_mac> <source_ip> <dest_ip> <dest_mac>'
			exit(0)
		source_mac = args[1]
		source_ip = args[2]
		dest_ip = args[3]
		dest_mac = args[4]
		print 'Sending reply to {}@{} answering {}@{}'.format(args[3],args[4],args[2],args[1])
		arp_rep(source_mac,source_ip,dest_ip,dest_mac)
	else:
		print 'Unrecognized command, please use either [request|reply]'
		exit(0)