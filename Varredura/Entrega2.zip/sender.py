#!/usr/bin/python

import struct
import socket
import sys

import time

# From http://www.bitforestinfo.com/2018/01/code-icmp-raw-packet-in-python.html
def checksum(msg):
	s = 0			 # Binary Sum
	# loop taking 2 characters at a time
	for i in range(0, len(msg), 2):
		a = ord(msg[i])
		b = ord(msg[i+1])
		s = s + (a+(b << 8))
	# One's Complement
	s = s + (s >> 16)
	s = ~s & 0xffff
	return socket.ntohs(s)

# Get ICMP code
icmp = socket.getprotobyname("icmp")

def send(dest_ip, sent, timeout = 100000):
	seq = 0
	while 1:
		seq += 1
		# Create a raw socket
		try:
			s = socket.socket(socket.AF_INET, socket.SOCK_RAW, icmp)
		except socket.error , msg:
			print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
			sys.exit()

		# ICMP header fields
		type = 8
		code = 0
		mychecksum = 0
		identifier = seq
		seqnumber = 0
		payload = str(seq)

		icmp_packet = struct.pack("!BBHHH6s", type, code, mychecksum, identifier, seqnumber, payload)

		# Recalculate checksum based on whole packet
		mychecksum = checksum(icmp_packet)

		icmp_packet = struct.pack("!BBHHH6s", type, code, mychecksum, identifier, seqnumber, payload)

		# Get destination address
		dest_addr = socket.gethostbyname(dest_ip)

		# print mychecksum
		sent[payload] = False

		# Send echo request
		start = time.time()
		s.sendto(icmp_packet, (dest_addr,0))

		for i in range(timeout):
			if sent[payload]:
				end = time.time()
				break
		
		if sent[payload]:
			print 'Ping Successful', 'Seq', seq, "RTT:", "{:.4f}ms".format(1000*(end-start),4)
		else:
			pass
			# print payload,sent[payload]
		time.sleep(1)

if __name__ == "__main__":
	send("192.168.0.1",{},0)