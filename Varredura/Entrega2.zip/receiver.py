
import socket, sys
from struct import *

#Convert a string of 6 characters of ethernet address into a dash separated hex string
def eth_addr (a) :
  b = "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (ord(a[0]) , ord(a[1]) , ord(a[2]), ord(a[3]), ord(a[4]) , ord(a[5]))
  return b

#create a AF_PACKET type raw socket (thats basically packet level)
#define ETH_P_ALL	0x0003		  /* Every packet (be careful!!!) */
try:
	s = socket.socket( socket.AF_PACKET , socket.SOCK_RAW , socket.ntohs(0x0003))
except socket.error , msg:
	print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
	sys.exit()

def receive(saddress, received, daddress):
	# receive a packet
	while True:
		(packet,addr) = s.recvfrom(65565) # bufsize - 64kbytes

		#parse ethernet header
		eth_length = 14

		eth_header = packet[:eth_length]
		eth = unpack('!6s6sH' , eth_header)
		eth_type = eth[2]

		#Parse IP packets, IP Protocol number = 0x0800
		if eth_type == 0x0800 :
			#Parse IP header
			#take first 20 characters for the ip header
			ip_header = packet[eth_length:20+eth_length]

			#now unpack them :)
			iph = unpack('!BBHHHBBH4s4s' , ip_header)

			version_ihl = iph[0]
			version = version_ihl >> 4
			ihl = version_ihl & 0xF

			iph_length = ihl * 4

			ttl = iph[5]
			protocol = iph[6]


			#ICMP Packets
			if protocol == 0x01 :
				s_addr = socket.inet_ntoa(iph[8]);
				d_addr = socket.inet_ntoa(iph[9]);

				if s_addr == saddress and d_addr == daddress:
					u = iph_length + eth_length
					icmph_length = 4
					icmp_header = packet[u:u+4]

					#now unpack them :)
					icmph = unpack('!BBH' , icmp_header)

					icmp_type = "Reply" if icmph[0] == 0 else "Request"
					
					h_size = eth_length + iph_length + icmph_length
					
					#get data from the packet
					data = packet[h_size+2:].replace('\x00','')

					if icmp_type == "Reply":
						received[data] = True


if __name__ == "__main__":
	wait("192.168.0.1",{},"192.168.0.10")