
import sys
import time
import thread

args = sys.argv[1:]

if len(args) == 0:
	exit(0)


src = "10.32.143.78"
target = args[0]

from sender import send
from receiver import receive

buff = {}
thread.start_new_thread(receive,(target,buff,src))
thread.start_new_thread(send,(target,buff))

while 1:
	time.sleep(100)