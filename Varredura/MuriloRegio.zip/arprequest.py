#!/usr/bin/python

import struct
import socket

def eth_addr (a) :
  b = "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (ord(a[0]) , ord(a[1]) , ord(a[2]), ord(a[3]), ord(a[4]) , ord(a[5]))
  return b

#Gets the info from the interface that communicates with the Internet
def myInfo(getMask = False):
	import os
	last = ["","",""]
	for line in os.popen("ip a"):
		last = last[1:] + [line.strip()]
		if "global" in line:
			break

	interface = last[0].split(':')[1].strip()
	mac = last[1].split(' ')[1]

	if getMask:
		return last[2].split(' ')[1].split('/')
	
	ip = last[2].split(' ')[1].split('/')[0]

	return interface, mac, ip

#Sends a ARP request
def request(ip):
	interface, mac, myip = myInfo()

	rawSocket = socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
	rawSocket.bind((interface, socket.htons(0x0800)))

	#Maps String MAC to Byte MAC
	encoded_mac = ''.join(map(lambda x : ("\\x"+x).decode('string_escape'), mac.split(':')))

	source_mac = encoded_mac        			# sender mac address
	source_ip  = myip           				# sender ip address
	dest_mac = "\xff\xff\xff\xff\xff\xff"   	# target mac address
	dest_ip  = ip             					# target ip address

	# Ethernet Header
	protocol = 0x0806                       # 0x0806 for ARP
	eth_hdr = struct.pack("!6s6sH", dest_mac, source_mac, protocol)

	# ARP header
	htype = 1                               # Hardware_type ethernet
	ptype = 0x0800                          # Protocol type IP
	hlen = 6                                # Hardware address Len
	plen = 4                                # Protocol addr. len
	operation = 1                           # 1=request/2=reply
	src_ip = socket.inet_aton(source_ip)
	dst_ip = socket.inet_aton(dest_ip)
	arp_hdr = struct.pack("!HHBBH6s4s6s4s", htype, ptype, hlen, plen, operation, source_mac, src_ip, dest_mac, dst_ip)

	packet = eth_hdr + arp_hdr
	rawSocket.send(packet)


if __name__ == "__main__":
	request(myInfo()[-1])
	# print myInfo()