
import socket, sys
import thread
from struct import *
from arprequest import request, myInfo

#Convert a string of 6 characters of ethernet address into a dash separated hex string
def eth_addr (a) :
  b = "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (ord(a[0]) , ord(a[1]) , ord(a[2]), ord(a[3]), ord(a[4]) , ord(a[5]))
  return b

#create a AF_PACKET type raw socket (thats basically packet level)
#define ETH_P_ALL	0x0003		  /* Every packet (be careful!!!) */
try:
	s = socket.socket( socket.AF_PACKET , socket.SOCK_RAW , socket.ntohs(0x0003))
except socket.error , msg:
	print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
	sys.exit()

# Prints info from the possible attacker
def warn(possible_victim_IP):
	possible_attacker_MAC = d[possible_victim_IP][1]
	possible_subnet, mask = myInfo(getMask=True)
	possible_subnet = '.'.join(possible_subnet.split('.')[:-1]+["0"])
	print 'Possible Attacker :', eth_addr(possible_attacker_MAC)
	print 'Subnet : {}/{}'.format(possible_subnet,mask)
	print ''

#Data structure to store the relation between
#IP --> (MAC from ARP, MAC from broadcasted ICMP req)
d = {}

# receive a packet
while True:
	(packet,addr) = s.recvfrom(65565) # bufsize - 64kbytes

	eth_length = 14

	eth_header = packet[:eth_length]
	eth = unpack('!6s6sH' , eth_header)
	eth_dstaddr = eth[0]
	eth_srcaddr = eth[1]
	eth_type = eth[2]

	#Parse IP packets, IP Protocol number = 0x0800
	if eth_type == 0x0800 :
		ip_header = packet[eth_length:20+eth_length]
		iph = unpack('!BBHHHBBH4s4s' , ip_header)
		
		# Only the protocol and IPs are relevant
		protocol = iph[6]
		s_addr = socket.inet_ntoa(iph[8]);
		d_addr = socket.inet_ntoa(iph[9]);

		#Checks if the packet is from ICMP
		if protocol == 0x01 :
			# and if it's being sent in broadcast
			if "255" in d_addr:
				#If it is then store it in a data structure for comparison
				if s_addr not in d:
					d[s_addr] = [None,None]

				d[s_addr][1] = eth_srcaddr

				#If the MAC of the sender is unknown, ask him
				if d[s_addr][0] is None:
					thread.start_new_thread(request,tuple([s_addr]))
					continue

				#If the knonw MAC and the sender MAC are different, war as possible attacker
				if d[s_addr][1] != d[s_addr][0]:
					warn(s_addr)

	#Parse ARP packets, ARP protocol numer = 0x0806
	elif eth_type == 0x0806 :
		arp_header = packet[eth_length:28+eth_length]
		arph = unpack("!HHBBH6s4s6s4s", arp_header)

		#We only want the IPs
		src_ip = socket.inet_ntoa(arph[6])
		dst_ip = socket.inet_ntoa(arph[8])

		#Then we store the info contained on the packet
		for ip, mac in [(src_ip,eth_srcaddr), (dst_ip, eth_dstaddr)]:
			if mac == "\xff\xff\xff\xff\xff\xff":#Broacast MAC
				continue

			if ip not in d:
				d[ip] = [None,None]

			d[ip][0] = mac

			#If someone had sent a broadcast ICMP echo request and
			#then MAC that sent it is different from the one that
			#was on the ARP package, then it's probably an attack
			if d[ip][1] != d[ip][0] and d[ip][1] is not None:
				warn(ip)